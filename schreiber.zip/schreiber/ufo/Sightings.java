package schreiber.ufo;

import java.util.ArrayList;

public class Sightings extends ArrayList<Sighting> {

}
