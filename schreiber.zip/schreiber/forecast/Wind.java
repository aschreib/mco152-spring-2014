package schreiber.forecast;

public class Wind {
private double speed;
private double deg;
public Wind(double speed, double deg) {
	this.speed = speed;
	this.deg = deg;
}

}
