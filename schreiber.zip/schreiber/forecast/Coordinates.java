package schreiber.forecast;



public class Coordinates {
	private double lon;
	private double lat;


	

}
