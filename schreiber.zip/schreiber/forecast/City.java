package schreiber.forecast;

public class City {
	private String id;
	private String name;
	private Coordinates coord;
	private String country;
	private String population;
	
}
