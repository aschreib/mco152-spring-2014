package schreiber.forecast;

public class Sys {
	private String pod;
	/**
	 * @param args
	 */


}
