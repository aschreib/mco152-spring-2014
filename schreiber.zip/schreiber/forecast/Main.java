package schreiber.forecast;

public class Main {
private double temp;
private double pressure;
private double humidity;
private double temp_min;
private double temp_max;
private double temp_kf;
private double grnd_level;
private double sea_level;




	public double getTemp() {
	return temp;
}


public void setTemp(double temp) {
	this.temp = temp;
}



	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
