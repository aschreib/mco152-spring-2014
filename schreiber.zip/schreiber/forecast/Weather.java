package schreiber.forecast;

public class Weather {
	private String id;
	private String main;
	private String description;
	private String icon;

}
