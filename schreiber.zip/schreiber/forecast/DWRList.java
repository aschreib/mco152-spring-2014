package schreiber.forecast;

import java.util.ArrayList;

public class DWRList extends ArrayList<DailyWeatherReport>{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2808737005763778474L;

}
