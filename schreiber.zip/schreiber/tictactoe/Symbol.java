package schreiber.tictactoe;

public enum Symbol {

	X, O

}
