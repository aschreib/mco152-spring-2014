package schreiber.flicker;

public class Item {

	private Media media;

	public Media getMedia() {
		return media;
	}

}