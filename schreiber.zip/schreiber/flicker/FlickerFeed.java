package schreiber.flicker;

/**
 * The class that represents the json feed from Flicker
 */
public class FlickerFeed {

	// TODO: add code here

	private Item[] items;

	public Item[] getItems() {
		return items;
	}

}
