package schreiber.flicker;

public class Media {

	private String m;

	public String getM() {
		return m;
	}

}
